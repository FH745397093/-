package com.sm.entity;

public class KCT_CASE_INFO {
	private String cname;
    private String cnid;
    private String kyno;
    private String jqno;
    private String createuser;
    private String lname;
    private String lid;
    private String lacsid;
    private String cellidbid;
    private String xhqd;
    private String nid;
    private String yystype;
    private String xhtype;
    private String isms;
    private String slong;
    private String slat;
    private String cdate;
    private String mlac;
    private String mcell;
    private String hlac;
    private String hcell;
    private String bzinfo;
    private String no3;
    private String no4;
    private String islastgps;
    private String baidujd;
    private String baiduwd;
    private String cellidlong;
    private String bztype;
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCnid() {
		return cnid;
	}
	public void setCnid(String cnid) {
		this.cnid = cnid;
	}
	public String getKyno() {
		return kyno;
	}
	public void setKyno(String kyno) {
		this.kyno = kyno;
	}
	public String getJqno() {
		return jqno;
	}
	public void setJqno(String jqno) {
		this.jqno = jqno;
	}
	public String getCreateuser() {
		return createuser;
	}
	public void setCreateuser(String createuser) {
		this.createuser = createuser;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getLid() {
		return lid;
	}
	public void setLid(String lid) {
		this.lid = lid;
	}
	public String getLacsid() {
		return lacsid;
	}
	public void setLacsid(String lacsid) {
		this.lacsid = lacsid;
	}
	public String getCellidbid() {
		return cellidbid;
	}
	public void setCellidbid(String cellidbid) {
		this.cellidbid = cellidbid;
	}
	public String getXhqd() {
		return xhqd;
	}
	public void setXhqd(String xhqd) {
		this.xhqd = xhqd;
	}
	public String getNid() {
		return nid;
	}
	public void setNid(String nid) {
		this.nid = nid;
	}
	public String getYystype() {
		return yystype;
	}
	public void setYystype(String yystype) {
		this.yystype = yystype;
	}
	public String getXhtype() {
		return xhtype;
	}
	public void setXhtype(String xhtype) {
		this.xhtype = xhtype;
	}
	public String getIsms() {
		return isms;
	}
	public void setIsms(String isms) {
		this.isms = isms;
	}
	public String getSlong() {
		return slong;
	}
	public void setSlong(String slong) {
		this.slong = slong;
	}
	public String getSlat() {
		return slat;
	}
	public void setSlat(String slat) {
		this.slat = slat;
	}
	public String getCdate() {
		return cdate;
	}
	public void setCdate(String cdate) {
		this.cdate = cdate;
	}
	public String getMlac() {
		return mlac;
	}
	public void setMlac(String mlac) {
		this.mlac = mlac;
	}
	public String getMcell() {
		return mcell;
	}
	public void setMcell(String mcell) {
		this.mcell = mcell;
	}
	public String getHlac() {
		return hlac;
	}
	public void setHlac(String hlac) {
		this.hlac = hlac;
	}
	public String getHcell() {
		return hcell;
	}
	public void setHcell(String hcell) {
		this.hcell = hcell;
	}
	public String getBzinfo() {
		return bzinfo;
	}
	public void setBzinfo(String bzinfo) {
		this.bzinfo = bzinfo;
	}
	public String getNo3() {
		return no3;
	}
	public void setNo3(String no3) {
		this.no3 = no3;
	}
	public String getNo4() {
		return no4;
	}
	public void setNo4(String no4) {
		this.no4 = no4;
	}
	public String getIslastgps() {
		return islastgps;
	}
	public void setIslastgps(String islastgps) {
		this.islastgps = islastgps;
	}
	public String getBaidujd() {
		return baidujd;
	}
	public void setBaidujd(String baidujd) {
		this.baidujd = baidujd;
	}
	public String getBaiduwd() {
		return baiduwd;
	}
	public void setBaiduwd(String baiduwd) {
		this.baiduwd = baiduwd;
	}
	public String getCellidlong() {
		return cellidlong;
	}
	public void setCellidlong(String cellidlong) {
		this.cellidlong = cellidlong;
	}
	public String getBztype() {
		return bztype;
	}
	public void setBztype(String bztype) {
		this.bztype = bztype;
	}
	
}
